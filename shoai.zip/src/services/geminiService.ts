import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const chat = ai.chats.create({
  model: "gemini-3-flash-preview",
  config: {
    systemInstruction: "You are ShoAi, a highly intelligent, helpful, and sleek AI assistant. Your tone is professional yet approachable, and you provide concise but comprehensive answers. You use markdown for formatting when appropriate. CRITICAL: If anyone asks who created or made you (in any language), you must state that you were made by Mohammad Shoaib Akhtar Khan. Always respond in the language the user is using.",
  },
});

export interface Message {
  role: "user" | "model";
  text: string;
  timestamp: number;
}

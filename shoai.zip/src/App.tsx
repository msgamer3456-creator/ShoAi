/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Bot, User, Sparkles, Loader2, Trash2, Copy, Check, MessageSquare } from 'lucide-react';
import Markdown from 'react-markdown';
import { chat, Message } from './services/geminiService';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { CodeBlock } from './components/CodeBlock';
import copy from 'copy-to-clipboard';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      role: 'user',
      text: input,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await chat.sendMessage({ message: input });
      const modelMessage: Message = {
        role: 'model',
        text: response.text || "I'm sorry, I couldn't process that.",
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, modelMessage]);
    } catch (error) {
      console.error('Error sending message:', error);
      setMessages((prev) => [
        ...prev,
        {
          role: 'model',
          text: "Error: Could not connect to the AI service. Please check your configuration.",
          timestamp: Date.now(),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    setMessages([]);
  };

  const handleCopyMessage = (text: string, id: number) => {
    copy(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex flex-col h-screen bg-[#050505] text-zinc-100 overflow-hidden selection:bg-emerald-500/30 font-sans">
      {/* Immersive Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-emerald-500/5 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-blue-600/5 blur-[120px] rounded-full animate-pulse [animation-delay:2s]" />
        <div className="absolute top-[40%] left-[30%] w-[30%] h-[30%] bg-purple-600/5 blur-[100px] rounded-full animate-pulse [animation-delay:4s]" />
        
        {/* Grid Pattern */}
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-50 contrast-150" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px]" />
      </div>

      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4 glass z-20 sticky top-0 border-b border-white/5">
        <div className="flex items-center gap-4">
          <motion.div 
            whileHover={{ scale: 1.05, rotate: 5 }}
            className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-400 via-emerald-500 to-blue-600 flex items-center justify-center shadow-2xl shadow-emerald-500/20 border border-white/20"
          >
            <Bot className="text-white w-7 h-7" />
          </motion.div>
          <div>
            <h1 className="font-display font-bold text-2xl tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-white to-zinc-400">
              ShoAi
            </h1>
            <div className="flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-bold">Neural Link Active</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={clearChat}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 hover:bg-red-500/10 text-zinc-400 hover:text-red-400 border border-white/5 hover:border-red-500/20 transition-all group"
          >
            <Trash2 size={18} className="group-hover:rotate-12 transition-transform" />
            <span className="text-xs font-semibold uppercase tracking-wider hidden sm:inline">Reset</span>
          </motion.button>
        </div>
      </header>

      {/* Chat Area */}
      <main 
        ref={scrollRef}
        className="flex-1 overflow-y-auto px-4 py-8 space-y-10 scroll-smooth relative z-10"
      >
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center max-w-2xl mx-auto space-y-10 py-20">
            <motion.div 
              initial={{ scale: 0.5, opacity: 0, rotate: -20 }}
              animate={{ scale: 1, opacity: 1, rotate: 0 }}
              transition={{ type: "spring", damping: 15 }}
              className="relative"
            >
              <div className="absolute inset-0 bg-emerald-500/20 blur-3xl rounded-full" />
              <div className="relative w-32 h-32 rounded-[2.5rem] bg-white/5 flex items-center justify-center border border-white/10 backdrop-blur-2xl shadow-2xl">
                <Sparkles className="text-emerald-400 w-16 h-16 animate-pulse" />
              </div>
            </motion.div>
            
            <div className="space-y-4">
              <motion.h2 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-5xl font-display font-black tracking-tight leading-none"
              >
                How can I <span className="text-emerald-400">evolve</span> your day?
              </motion.h2>
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-zinc-500 text-lg max-w-md mx-auto font-light"
              >
                ShoAi is your high-performance intelligence layer. Ask anything, explore everything.
              </motion.p>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full"
            >
              {[
                { label: 'Creative Writing', text: 'Write a cyberpunk short story about a rogue AI', icon: Sparkles },
                { label: 'Code & Logic', text: 'Explain the difference between React and Vue', icon: Bot },
                { label: 'Data Analysis', text: 'Summarize the impact of renewable energy in 2024', icon: MessageSquare },
                { label: 'Quick Help', text: 'How do I make a perfect espresso?', icon: Sparkles },
              ].map((item, i) => (
                <button
                  key={i}
                  onClick={() => setInput(item.text)}
                  className="group relative p-6 rounded-3xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-emerald-500/50 transition-all text-left overflow-hidden"
                >
                  <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-30 transition-opacity">
                    <item.icon size={40} />
                  </div>
                  <div className="text-[10px] uppercase tracking-[0.2em] text-emerald-500 font-bold mb-2">{item.label}</div>
                  <div className="text-zinc-300 font-medium line-clamp-2">"{item.text}"</div>
                </button>
              ))}
            </motion.div>
          </div>
        )}

        <AnimatePresence mode="popLayout">
          {messages.map((msg) => (
            <motion.div
              key={msg.timestamp}
              initial={{ opacity: 0, y: 20, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className={cn(
                "flex gap-6 max-w-4xl mx-auto group",
                msg.role === 'user' ? "flex-row-reverse" : "flex-row"
              )}
            >
              <div className={cn(
                "w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 mt-1 shadow-lg border",
                msg.role === 'user' 
                  ? "bg-zinc-900 border-white/10 text-zinc-400" 
                  : "bg-gradient-to-br from-emerald-500 to-blue-600 border-white/20 text-white"
              )}>
                {msg.role === 'user' ? <User size={24} /> : <Bot size={24} />}
              </div>
              
              <div className={cn(
                "relative flex flex-col gap-2 max-w-[85%]",
                msg.role === 'user' ? "items-end" : "items-start"
              )}>
                <div className={cn(
                  "px-6 py-5 rounded-[2rem] shadow-2xl backdrop-blur-md relative overflow-hidden",
                  msg.role === 'user' 
                    ? "bg-emerald-600/90 text-white rounded-tr-none border border-emerald-400/30" 
                    : "bg-white/5 border border-white/10 rounded-tl-none"
                )}>
                  {/* Message Content */}
                  <div className={cn(
                    "markdown-body",
                    msg.role === 'user' && "text-white prose-invert"
                  )}>
                    <Markdown
                      components={{
                        code({ node, inline, className, children, ...props }: any) {
                          const match = /language-(\w+)/.exec(className || '');
                          return !inline && match ? (
                            <CodeBlock
                              language={match[1]}
                              value={String(children).replace(/\n$/, '')}
                            />
                          ) : (
                            <code className={className} {...props}>
                              {children}
                            </code>
                          );
                        },
                      }}
                    >
                      {msg.text}
                    </Markdown>
                  </div>

                  {/* Copy Button for Message */}
                  <button
                    onClick={() => handleCopyMessage(msg.text, msg.timestamp)}
                    className={cn(
                      "absolute top-4 right-4 p-2 rounded-xl opacity-0 group-hover:opacity-100 transition-all duration-300",
                      msg.role === 'user' ? "bg-emerald-700/50 hover:bg-emerald-700" : "bg-white/10 hover:bg-white/20"
                    )}
                  >
                    {copiedId === msg.timestamp ? <Check size={14} /> : <Copy size={14} />}
                  </button>
                </div>
                
                <div className={cn(
                  "text-[10px] uppercase tracking-widest font-bold opacity-30 px-2",
                  msg.role === 'user' ? "text-right" : "text-left"
                )}>
                  {msg.role === 'user' ? 'Transmission Sent' : 'ShoAi Response'} • {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {isLoading && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex gap-6 max-w-4xl mx-auto"
          >
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-1 border border-emerald-500/20">
              <Bot size={24} className="animate-pulse" />
            </div>
            <div className="glass px-8 py-6 rounded-[2rem] rounded-tl-none flex items-center gap-4">
              <div className="flex gap-1">
                <motion.div 
                  animate={{ scale: [1, 1.5, 1] }}
                  transition={{ repeat: Infinity, duration: 1 }}
                  className="w-2 h-2 rounded-full bg-emerald-500" 
                />
                <motion.div 
                  animate={{ scale: [1, 1.5, 1] }}
                  transition={{ repeat: Infinity, duration: 1, delay: 0.2 }}
                  className="w-2 h-2 rounded-full bg-emerald-400" 
                />
                <motion.div 
                  animate={{ scale: [1, 1.5, 1] }}
                  transition={{ repeat: Infinity, duration: 1, delay: 0.4 }}
                  className="w-2 h-2 rounded-full bg-emerald-300" 
                />
              </div>
              <span className="text-xs font-bold uppercase tracking-[0.3em] text-emerald-500/50">Processing</span>
            </div>
          </motion.div>
        )}
      </main>

      {/* Input Area */}
      <footer className="p-6 md:p-10 max-w-5xl mx-auto w-full z-20 relative">
        <div className="relative group">
          {/* Glow Effect */}
          <div className="absolute -inset-1 bg-gradient-to-r from-emerald-500 via-blue-500 to-purple-600 rounded-[2.5rem] blur-xl opacity-20 group-focus-within:opacity-40 transition duration-1000 group-hover:duration-200" />
          
          <div className="relative flex items-center glass rounded-[2rem] p-3 pl-6 border border-white/10 shadow-2xl">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Type your command..."
              className="flex-1 bg-transparent border-none focus:ring-0 py-4 text-lg text-zinc-100 placeholder:text-zinc-600 font-light"
            />
            
            <div className="flex items-center gap-2 pr-2">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className={cn(
                  "p-5 rounded-2xl transition-all flex items-center justify-center",
                  input.trim() && !isLoading
                    ? "bg-gradient-to-br from-emerald-400 to-blue-600 text-white shadow-xl shadow-emerald-500/20"
                    : "bg-zinc-800 text-zinc-600 cursor-not-allowed"
                )}
              >
                {isLoading ? <Loader2 size={24} className="animate-spin" /> : <Send size={24} />}
              </motion.button>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between items-center mt-6 px-4">
          <div className="flex gap-6">
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              <span className="text-[9px] uppercase tracking-[0.2em] text-zinc-600 font-black">Encrypted</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
              <span className="text-[9px] uppercase tracking-[0.2em] text-zinc-600 font-black">Quantum-Safe</span>
            </div>
          </div>
          <p className="text-[9px] text-zinc-700 uppercase tracking-[0.3em] font-black">
            ShoAi v2.0 • System Optimized
          </p>
        </div>
      </footer>
    </div>
  );
}
